from setuptools import setup

setup(
    name="Paquete_CaterinaGalafassi_SegundaEntrega",
    version='0.0.1',
    author="Caterina Galafassi",
    author_email="categalafassi@gmail.com",
    description="Segunda entrega del curso inicial de Python de Coderhouse",
    packages=["CaterinaGalafassi_SegundaEntrega"]
)